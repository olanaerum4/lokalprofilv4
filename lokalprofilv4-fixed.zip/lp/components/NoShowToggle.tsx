'use client'
import { useState } from 'react'
import { browserClient } from '@/lib/supabase'

export default function NoShowToggle({ customerId, initial }: { customerId: string; initial: boolean }) {
  const [noShow, setNoShow] = useState(initial)
  const [loading, setLoading] = useState(false)
  const sb = browserClient()

  async function toggle() {
    setLoading(true)
    const next = !noShow
    await sb.from('customers').update({ no_show: next }).eq('id', customerId)
    setNoShow(next)
    setLoading(false)
  }

  return (
    <button onClick={toggle} disabled={loading}
      title={noShow ? 'Marker som møtt' : 'Marker som no-show'}
      className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border transition-colors ${
        noShow ? 'bg-orange-100 text-orange-600 border-orange-200 hover:bg-orange-50'
               : 'bg-gray-100 text-gray-400 border-gray-200 hover:bg-orange-50 hover:text-orange-500 hover:border-orange-200'
      }`}>
      {noShow ? '⚠ No-show' : 'No-show?'}
    </button>
  )
}
