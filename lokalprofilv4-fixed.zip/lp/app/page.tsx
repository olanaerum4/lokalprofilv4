import { redirect } from 'next/navigation'
import Link from 'next/link'

export default function Home() {
  // redirect('/dashboard')
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50">
      <h1 className="text-4xl font-bold mb-4">Lokalprofil</h1>
      <p className="text-gray-600 mb-8">Din lokale bedriftsplattform</p>
      <div className="space-x-4">
        <Link href="/login" className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
          Logg inn
        </Link>
        <Link href="/register" className="px-6 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300">
          Registrer deg
        </Link>
      </div>
    </div>
  )
}
